# Panfolio release

Version: 0.3.0

Content version: f10f97fd39de9486a36b45abf7308fe527122e2f8ba99f353e6378a8de4a59ed

Guidance version: b6b681d7a328c27755bb3d4c86937bf123a9f645837ccf246cd50590a842c505

Source revision: local

This is the package build identity. Installed skills read the current remote guide at the start of each new task. Keep retrieved text during an active cooking conversation.
