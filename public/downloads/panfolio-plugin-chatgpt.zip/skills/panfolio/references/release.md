# Panfolio release

Version: 0.1.0

Content version: a99a58b086ea9b82b2580056ecd776d5d0bfee8cfabc36ca4cf8b4ac612dfc66

Guidance version: 737b9ca611bb7d94dc6b5bbf25fcf5825f31eb51f2ec31f69f4ff7828d62ec55

Source revision: local

CI release archives pin cookbook links to this source revision. Repository installations follow the current main branch. Keep retrieved text during an active cooking conversation.
