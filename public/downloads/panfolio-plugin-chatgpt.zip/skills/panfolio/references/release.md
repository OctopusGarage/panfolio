# Panfolio release

Version: 0.2.0

Content version: 1ff4f539bb19e19758b4f924095e36a09332c5c202379354effc6a55e0a514af

Guidance version: b6b681d7a328c27755bb3d4c86937bf123a9f645837ccf246cd50590a842c505

Source revision: local

CI release archives pin cookbook links to this source revision. Repository installations follow the current main branch. Keep retrieved text during an active cooking conversation.
