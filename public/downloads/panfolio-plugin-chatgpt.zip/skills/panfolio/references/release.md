# Panfolio release

Version: 0.3.1

Content version: a6614e3bf27b2dda93a09e9b1d7a65c25abe5a4dd56110c55687c798d5394181

Guidance version: b6b681d7a328c27755bb3d4c86937bf123a9f645837ccf246cd50590a842c505

Source revision: local

This is the package build identity. Installed skills read the current remote guide at the start of each new task. Keep retrieved text during an active cooking conversation.
